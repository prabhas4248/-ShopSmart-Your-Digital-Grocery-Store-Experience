import React from 'react';
import { ArrowRight, Truck, Clock, Shield } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gradient-to-r from-emerald-50 to-green-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Fresh Groceries
                <span className="text-emerald-600"> Delivered</span>
              </h1>
              <p className="text-lg lg:text-xl text-gray-600 leading-relaxed">
                Get fresh, quality groceries delivered to your doorstep in under 30 minutes. 
                Shop from thousands of products at the best prices.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2">
                <span>Start Shopping</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="border border-emerald-500 text-emerald-600 hover:bg-emerald-50 px-8 py-3 rounded-lg font-medium transition-colors">
                View Offers
              </button>
            </div>
            
            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8">
              <div className="flex items-center space-x-3">
                <div className="bg-emerald-100 p-2 rounded-lg">
                  <Truck className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Free Delivery</p>
                  <p className="text-sm text-gray-600">Orders over $50</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">30 Min Delivery</p>
                  <p className="text-sm text-gray-600">Lightning fast</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="bg-orange-100 p-2 rounded-lg">
                  <Shield className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Fresh Guarantee</p>
                  <p className="text-sm text-gray-600">100% quality</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Content - Image */}
          <div className="relative">
            <div className="relative z-10">
              <img
                src="https://images.pexels.com/photos/4947663/pexels-photo-4947663.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Fresh groceries"
                className="w-full h-96 lg:h-[500px] object-cover rounded-2xl shadow-2xl"
              />
            </div>
            
            {/* Floating cards */}
            <div className="absolute top-4 right-4 bg-white p-4 rounded-lg shadow-lg z-20">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-bold">✓</span>
                </div>
                <div>
                  <p className="font-semibold text-sm">Fresh Produce</p>
                  <p className="text-xs text-gray-600">Farm to table</p>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-4 left-4 bg-white p-4 rounded-lg shadow-lg z-20">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold">$</span>
                </div>
                <div>
                  <p className="font-semibold text-sm">Best Prices</p>
                  <p className="text-xs text-gray-600">Guaranteed low</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;